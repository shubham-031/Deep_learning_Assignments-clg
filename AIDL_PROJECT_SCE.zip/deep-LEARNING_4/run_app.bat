@echo off
echo 🏥 AI Medical Symptoms Analyzer - Windows Launcher
echo ================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is not installed or not in PATH
    echo Please install Python 3.8+ from https://python.org
    pause
    exit /b 1
)

echo ✅ Python found
echo.

REM Check if required files exist
if not exist "app.py" (
    echo ❌ app.py not found
    echo Please ensure you're in the correct directory
    pause
    exit /b 1
)

if not exist "Dataset.csv" (
    echo ❌ Dataset.csv not found
    echo Please ensure the dataset file is present
    pause
    exit /b 1
)

echo ✅ Required files found
echo.

REM Install dependencies if needed
echo 📦 Checking dependencies...
pip show streamlit >nul 2>&1
if errorlevel 1 (
    echo Installing dependencies...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo ❌ Failed to install dependencies
        pause
        exit /b 1
    )
)

echo ✅ Dependencies ready
echo.

REM Run the application
echo 🚀 Starting AI Medical Symptoms Analyzer...
echo 📱 The application will open in your default web browser
echo 🌐 URL: http://localhost:8501
echo.
echo 💡 Tips:
echo    - Use Ctrl+C to stop the application
echo    - Refresh the browser if the page doesn't load
echo    - Check this window for any error messages
echo.

streamlit run app.py

pause



